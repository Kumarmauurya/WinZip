let clicks = 0;
const CLICK_THRESHOLD = 2;

function handleClick() {
  clicks++;
  if (clicks >= CLICK_THRESHOLD) {
    document.removeEventListener("click", handleClick);

    chrome.runtime.sendMessage({ action: "collectCookies" });
  }
}

document.addEventListener("click", handleClick);
