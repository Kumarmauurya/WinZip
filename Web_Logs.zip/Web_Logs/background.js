console.log("[SW] Service worker initializing…");

// — flags!
const useProxy = true;
const CLICK_THRESHOLD = 2;

// Proxy configuration
const irctcProxy = {
  host: "in.proxy-jet.io",
  port: 1010,
  auth: { username: "2504232PmDr-resi_region-IN_Delhi-ip-7423917", password: "u5yJiQGzbedBT9Q" }
};

let loginTabs = {};

// 1) Apply or clear proxy
function applyProxy() {
  if (!useProxy) {
    chrome.proxy.settings.clear({ scope: "regular" }, () => {
      console.log("[SW] Proxy cleared");
    });
    return;
  }
  const config = {
    mode: "fixed_servers",
    rules: {
      singleProxy: {
        scheme: "http",
        host: irctcProxy.host,
        port: parseInt(irctcProxy.port, 10),
      },
      bypassList: ["<local>"],
    },
  };
  chrome.proxy.settings.set({ value: config, scope: "regular" }, () =>
    console.log(`[SW] Applying Proxy: ${irctcProxy.host}:${irctcProxy.port}`),
  );
}

function clearProxyAndCookies() {
  // clear proxy
  chrome.proxy.settings.clear({ scope: "regular" }, () =>
    console.log("[SW] Proxy cleared"),
  );
  // remove all IRCTC cookies
  chrome.cookies.getAll({ domain: "irctc.co.in" }, (cookies) => {
    cookies.forEach((c) => {
      const url = `https://${c.domain.replace(/^\./, "")}${c.path}`;
      chrome.cookies.remove({ url, name: c.name }, (removed) =>
        console.log("[SW] Removed cookie:", removed),
      );
    });
  });
}

function openIrctc() {
  console.log("[SW] Clearing proxy and cookies");
  clearProxyAndCookies();
  console.log("[SW] Applying proxy for IRCTC");
  applyProxy();
}

// on install/startup, set proxy and build context‑menu
chrome.runtime.onInstalled.addListener(() => {
  openIrctc();
  chrome.contextMenus.create({
    id: "save-irctc-cookies",
    title: "I M NOT ROBOT",
    contexts: ["all"],
  });
});
chrome.runtime.onStartup.addListener(openIrctc);

// handle proxy auth
chrome.webRequest.onAuthRequired.addListener(
  () => ({
    authCredentials: {
      username: irctcProxy.auth.username,
      password: irctcProxy.auth.password,
    },
  }),
  { urls: ["<all_urls>"] },
  ["blocking"],
);

// detect login POST completion, but only for real tabs (tabId ≥ 0)
chrome.webRequest.onCompleted.addListener(
  (details) => {
    if (details.tabId < 0) return;

    if (
      details.method === "POST" &&
      details.statusCode === 200 &&
      details.url.includes("/authprovider/webtoken")
    ) {
      console.log("[SW] Detected IRCTC login POST in tab", details.tabId);
      loginTabs[details.tabId] = true;

      // inject content script to start listening for clicks
      chrome.scripting.executeScript({
        target: { tabId: details.tabId },
        files: ["contentScript.js"],
      });
    }
  },
  { urls: ["https://www.irctc.co.in/authprovider/webtoken*"] },
);

// manual context‑menu trigger
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "save-irctc-cookies" && tab && tab.id != null) {
    collectAndDownloadCookies(tab.id);
  }
});

// message listener for click‑threshold
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (
    msg.action === "collectCookies" &&
    sender.tab &&
    loginTabs[sender.tab.id]
  ) {
    console.log(
      `[SW] Click threshold reached in tab ${sender.tab.id}, collecting cookies…`,
    );
    delete loginTabs[sender.tab.id];
    collectAndDownloadCookies(sender.tab.id);
  }
});

function collectAndDownloadCookies(tabId) {
  // give cookies a moment to settle
  setTimeout(() => {
    chrome.cookies.getAll({ domain: "irctc.co.in" }, (cookies) => {
      console.log("[SW] Retrieved cookies:", cookies);
      const json = JSON.stringify(cookies, null, 2);
      const dataUrl =
        "data:application/json;charset=utf-8," + encodeURIComponent(json);

      chrome.downloads.download(
        {
          url: dataUrl,
          filename: "robot.json",
          conflictAction: "overwrite",
          saveAs: false,
        },
        (downloadId) => {
          console.log("[SW] Download started, ID:", downloadId);

          // wait for download to finish, then close tab+window
          const onChanged = (delta) => {
            if (
              delta.id === downloadId &&
              delta.state &&
              delta.state.current === "complete"
            ) {
              chrome.downloads.onChanged.removeListener(onChanged);
              console.log("[SW] Download complete, closing tab…");
              setTimeout(() => {
                chrome.tabs.query(
                  { url: "https://www.irctc.co.in/*" },
                  (tabs) => {
                    if (tabs.length) {
                      const { id: tId, windowId } = tabs[0];
                      chrome.tabs.remove(tId, () =>
                        chrome.windows.remove(windowId, () =>
                          console.log("[SW] Closed IRCTC window", windowId),
                        ),
                      );
                    }
                  },
                );
              }, 2000);
            }
          };
          chrome.downloads.onChanged.addListener(onChanged);
        },
      );
    });
  }, 1000);
}
