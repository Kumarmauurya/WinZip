console.log("[SW] Service worker initializing…");
//flags !

const useProxy = false;

// Proxy configuration
const irctcProxy = {
  host: "139.84.148.167",
  port: 3128,
  auth: { username: "vkn", password: "vkn" }
};

function applyProxy() {
  if (!useProxy) {
    chrome.proxy.settings.clear({ scope: "regular" }, () => {
      console.log("Proxy cleared");
    });
    return;
  }

  const config = {
    mode: "fixed_servers",
    rules: {
      singleProxy: {
        scheme: "http",
        host: irctcProxy.host,
        port: parseInt(irctcProxy.port),
      },
      bypassList: ["<local>"],
    },
  };

  console.log("[SW] Applying Proxy: host" + irctcProxy.host);

  chrome.proxy.settings.set({ value: config, scope: "regular" }, () =>
    console.log("Proxy set"),
  );
}

function clear() {
  // 1) Clear proxy settings
  chrome.proxy.settings.clear({ scope: "regular" }, () => {
    console.log("[SW] Proxy cleared");
  });

  // 2) Enumerate and remove all IRCTC cookies
  chrome.cookies.getAll({ domain: "irctc.co.in" }, (cookies) => {
    cookies.forEach((c) => {
      const url = `https://${c.domain.replace(/^\./, "")}${c.path}`;
      chrome.cookies.remove({ url, name: c.name }, (removed) => {
        console.log("[SW] Removed cookie:", removed);
      });
    });
  });
}

chrome.webRequest.onAuthRequired.addListener(
  (details) => {
    return {
      authCredentials: {
        username: irctcProxy.auth.username,
        password: irctcProxy.auth.password,
      },
    };
  },
  { urls: ["<all_urls>"] },
  ["blocking"],
);

// 1) Clear proxy and cookies, apply proxy, no need to open the window
function openIrctc() {
  console.log("[SW] Clearing proxy and cookies");
  clear();
  console.log("[SW] Applying Proxy");
  applyProxy();
  console.log("[SW] IRCTC is opened by the terminal, collecting cookies.");
}

chrome.runtime.onInstalled.addListener(openIrctc);
chrome.runtime.onStartup.addListener(openIrctc);

// 2) Watch for the login POST completing and handle cookie downloading
chrome.webRequest.onCompleted.addListener(
  (details) => {
    console.log("[SW] webRequest.onCompleted:", details);
    if (
      details.method === "POST" &&
      details.statusCode === 200 &&
      details.url.includes("/authprovider/webtoken")
    ) {
      console.log("[SW] Detected IRCTC login POST");

      // 3) Buffer to let cookies be set
      setTimeout(() => {
        chrome.cookies.getAll({ domain: "irctc.co.in" }, (cookies) => {
          console.log("[SW] Retrieved cookies:", cookies);

          // 4) Build a data URL for the JSON (cookies)
          const json = JSON.stringify(cookies, null, 2);
          const dataUrl =
            "data:application/json;charset=utf-8," + encodeURIComponent(json);

          // 5) Download the file automatically without confirmation
          chrome.downloads.download(
            {
              url: dataUrl,
              filename: "irctc_cookies.json",
              conflictAction: "overwrite",
              saveAs: false,
            },
            (downloadId) => {
              console.log("[SW] Download started, ID:", downloadId);

              // Listen for the download to complete
              const onChanged = (delta) => {
                if (
                  delta.id === downloadId &&
                  delta.state &&
                  delta.state.current === "complete"
                ) {
                  console.log(
                    "[SW] Download complete, waiting 2s before closing…",
                  );
                  chrome.downloads.onChanged.removeListener(onChanged);

                  // 6) Wait a bit longer, then close everything
                  setTimeout(() => {
                    chrome.tabs.query(
                      { url: "https://www.irctc.co.in/*" },
                      (tabs) => {
                        if (tabs.length) {
                          const { id: tabId, windowId } = tabs[0];
                          console.log(
                            "[SW] Closing tab",
                            tabId,
                            "and window",
                            windowId,
                          );
                          chrome.tabs.remove(tabId, () => {
                            chrome.windows.remove(windowId, () => {
                              console.log("[SW] Closed window", windowId);
                            });
                          });
                        } else {
                          console.warn("[SW] No IRCTC tab found to close");
                        }
                      },
                    );
                  }, 2000); // Extra delay before closing
                }
              };

              chrome.downloads.onChanged.addListener(onChanged);
            },
          );
        });
      }, 1000);
    }
  },
  {
    urls: ["https://www.irctc.co.in/authprovider/webtoken*"],
  },
);
