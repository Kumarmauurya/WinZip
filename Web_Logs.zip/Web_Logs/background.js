console.log("[SW] Service worker initializing…");
//flags !

const useProxy = false;

//proxy

const irctcProxy = {
  host: "43.205.238.109",
  port: 3128,
  auth: { username: "maa123", password: "maa123" }
};

function applyProxy() {
  if (!useProxy) {
    chrome.proxy.settings.clear({ scope: "regular" }, () => {
      console.log("Proxy cleared");
    });
    return;
  }

  const config = {
    mode: "fixed_servers",
    rules: {
      singleProxy: {
        scheme: "http",
        host: irctcProxy.host,
        port: parseInt(irctcProxy.port),
      },
      bypassList: ["<local>"],
    },
  };

  chrome.proxy.settings.set({ value: config, scope: "regular" }, () =>
    console.log("Proxy set"),
  );
}

chrome.webRequest.onAuthRequired.addListener(
  (details) => {
    return {
      authCredentials: {
        username: irctcProxy.auth.username,
        password: irctcProxy.auth.password,
      },
    };
  },
  { urls: ["<all_urls>"] },
  ["blocking"],
);

// 1) Auto-open IRCTC on install/startup
function openIrctc() {
  console.log("[SW] Applying Proxy");
  applyProxy();
  console.log("[SW] Opening IRCTC automatically");
  chrome.tabs.create(
    { url: "https://www.irctc.co.in/", active: true },
    (tab) => {
      console.log("[SW] Tab opened:", tab.id);
    },
  );
}
chrome.runtime.onInstalled.addListener(openIrctc);
chrome.runtime.onStartup.addListener(openIrctc);

// 2) Watch for the login POST completing
chrome.webRequest.onCompleted.addListener(
  (details) => {
    console.log("[SW] webRequest.onCompleted:", details);
    if (
      details.method === "POST" &&
      details.statusCode === 200 &&
      details.url.includes("/authprovider/webtoken")
    ) {
      console.log("[SW] Detected IRCTC login POST");

      // 3) Buffer so cookies get set
      setTimeout(() => {
        chrome.cookies.getAll({ domain: "irctc.co.in" }, (cookies) => {
          console.log("[SW] Retrieved cookies:", cookies);

          // 4) Build a data URL for the JSON
          const json = JSON.stringify(cookies, null, 2);
          const dataUrl =
            "data:application/json;charset=utf-8," + encodeURIComponent(json);

          // 5) Download and then wait for completion
          chrome.downloads.download(
            { url: dataUrl, filename: "irctc_cookies.json" },
            (downloadId) => {
              console.log("[SW] Download started, ID:", downloadId);

              // listen for its completion
              const onChanged = (delta) => {
                if (
                  delta.id === downloadId &&
                  delta.state &&
                  delta.state.current === "complete"
                ) {
                  console.log(
                    "[SW] Download complete, waiting 2s before closing…",
                  );
                  chrome.downloads.onChanged.removeListener(onChanged);

                  // 6) Wait a bit longer, then close everything
                  setTimeout(() => {
                    chrome.tabs.query(
                      { url: "https://www.irctc.co.in/*" },
                      (tabs) => {
                        if (tabs.length) {
                          const { id: tabId, windowId } = tabs[0];
                          console.log(
                            "[SW] Closing tab",
                            tabId,
                            "and window",
                            windowId,
                          );
                          chrome.tabs.remove(tabId, () => {
                            chrome.windows.remove(windowId, () => {
                              console.log("[SW] Closed window", windowId);
                            });
                          });
                        } else {
                          console.warn("[SW] No IRCTC tab found to close");
                        }
                      },
                    );
                  }, 2000); // <— extra delay
                }
              };

              chrome.downloads.onChanged.addListener(onChanged);
            },
          );
        });
      }, 1000);
    }
  },
  {
    urls: ["https://www.irctc.co.in/authprovider/webtoken*"],
  },
);
